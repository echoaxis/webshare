# Description

This resource allows users to create Office 365 Shared Mailboxes.
