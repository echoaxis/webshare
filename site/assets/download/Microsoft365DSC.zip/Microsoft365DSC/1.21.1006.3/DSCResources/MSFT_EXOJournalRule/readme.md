# Description

This resource allows to configure Journal Rules in Exchange Online.
