# SCDeviceConditionalAccessPolicy

## Description

This resource configures a Device Conditional Access Policy in Security and Compliance.
