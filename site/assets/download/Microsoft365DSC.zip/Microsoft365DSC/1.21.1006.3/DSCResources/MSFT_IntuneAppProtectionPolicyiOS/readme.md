
# IntuneDeviceConfigurationPolicyiOS

This resource configures an Intune device configuration profile for an iOS Device.
