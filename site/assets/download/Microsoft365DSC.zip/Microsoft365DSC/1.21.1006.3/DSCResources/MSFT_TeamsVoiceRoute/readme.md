
# TeamsVoiceRoute

This resource configures a Teams Voice Route.
