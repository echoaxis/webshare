# EXOTransportRule

## Description

This resource configures Transport Rules in Exchange Online.
