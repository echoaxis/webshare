# EXOGlobalAddressList

## Description

This resource configures Global Address Lists in Exchange Online.
