# EXOMobileDeviceMailboxPolicy

## Description

This resource configures Mobile Device Mailbox Policies in Exchange Online.
