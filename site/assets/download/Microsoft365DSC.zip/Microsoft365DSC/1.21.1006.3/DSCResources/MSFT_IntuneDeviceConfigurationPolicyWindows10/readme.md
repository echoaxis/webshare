
# IntuneDeviceConfigurationPolicyWindows10

This resource configures an Intune device configuration profile for an Windows 10 Device.
