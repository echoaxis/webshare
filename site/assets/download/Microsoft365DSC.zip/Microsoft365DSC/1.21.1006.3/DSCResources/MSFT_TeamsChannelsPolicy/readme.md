
# TeamsChannelsPolicy

This resource configures a Teams Channel Policy.
