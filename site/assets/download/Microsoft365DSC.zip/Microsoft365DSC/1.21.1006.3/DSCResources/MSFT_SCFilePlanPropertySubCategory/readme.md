# SCFilePlanPropertySubCategory

## Description

This resource configures a sub-category entry for Security and
Compliance File Plans.
