
# TeamsMeetingPolicy

This resource configures the Teams Meeting Policies.
