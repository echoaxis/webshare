# EXOApplicationAccessPolicy

## Description

This resource configures Applications Access Policies in Exchange Online.
