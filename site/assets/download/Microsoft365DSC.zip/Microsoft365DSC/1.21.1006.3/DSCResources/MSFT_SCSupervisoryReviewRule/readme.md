# SCSupervisoryReviewRule

## Description

This resource configures a Supervision Review Rule in Security and Compliance.
