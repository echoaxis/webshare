# EXOManagementRole

## Description

This resource configures RBAC Management Roles in Exchange Online.
