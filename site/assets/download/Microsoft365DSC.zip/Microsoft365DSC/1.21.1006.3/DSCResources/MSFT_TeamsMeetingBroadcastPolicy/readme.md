# Description

This resource is used to configure the Teams Meeting Broadcast Policies.
