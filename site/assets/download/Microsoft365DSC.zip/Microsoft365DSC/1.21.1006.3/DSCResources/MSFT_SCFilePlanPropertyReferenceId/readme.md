# SCFilePlanPropertyReferenceId

## Description

This resource configures a reference ID entry for Security and
Compliance File Plans.
