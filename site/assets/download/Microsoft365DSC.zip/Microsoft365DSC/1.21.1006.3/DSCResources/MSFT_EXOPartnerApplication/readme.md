# EXOPartnerApplication

## Description

This resource configures Partner Applications in Exchange Online.
