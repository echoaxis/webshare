# SCComplianceSearch

## Description

This resource configures an Compliance Search (eDiscovery) in Security and Compliance.
