
# TeamsPstnUsage

This resource configures a Teams PSTN Usage.
