
# IntuneAppConfigurationPolicy

This resource configures the Intune App configuration policies.
