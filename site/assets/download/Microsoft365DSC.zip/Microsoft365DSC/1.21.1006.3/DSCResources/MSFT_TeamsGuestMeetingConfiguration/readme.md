# Description

This resource is used to configure the Teams Guest Meetings Configuration.
