# SCComplianceSearchAction

## Description

This resource configures a Compliance Search Action in Security and Compliance.
