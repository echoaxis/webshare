# SCDeviceConfigurationPolicy

## Description

This resource configures a Device Configuration Policy in Security and Compliance.
