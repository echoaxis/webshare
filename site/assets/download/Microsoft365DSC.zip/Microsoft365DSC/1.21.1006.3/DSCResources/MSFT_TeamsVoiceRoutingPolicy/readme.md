
# TeamsVoiceRoutingPolicy

This resource configures a Teams Voice Routing Policy.
