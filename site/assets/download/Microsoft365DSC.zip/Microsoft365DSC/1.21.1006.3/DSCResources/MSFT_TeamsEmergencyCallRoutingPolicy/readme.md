
# TeamsEmergencyCallRoutingPolicy

This resource configures the Teams Emergency Call Routing Policies.
