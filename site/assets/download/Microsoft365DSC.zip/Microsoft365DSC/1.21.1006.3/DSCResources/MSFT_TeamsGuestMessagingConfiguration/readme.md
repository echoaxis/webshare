# Description

This resource is used to configure the Teams Guest Messaging Configuration.
