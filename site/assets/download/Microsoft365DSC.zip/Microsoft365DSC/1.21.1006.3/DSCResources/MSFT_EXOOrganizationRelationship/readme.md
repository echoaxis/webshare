# EXOOrganizationRelationship

## Description

This resource configures the Organization Relationship in Exchange Online.
