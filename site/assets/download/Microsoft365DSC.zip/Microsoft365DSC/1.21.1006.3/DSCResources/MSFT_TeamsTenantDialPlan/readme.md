# Description

This resource is used to configure the tenant-wide dial plans for Microsoft Teams.
