
# TeamsCallingPolicy

This resource configures a Teams Calling Policy.
