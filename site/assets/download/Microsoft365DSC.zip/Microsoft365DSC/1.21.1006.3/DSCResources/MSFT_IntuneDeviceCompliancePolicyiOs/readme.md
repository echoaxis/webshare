
# IntuneDeviceCompliancePolicyiOs

This resource configures the Intune compliance policies for iOs devices.
