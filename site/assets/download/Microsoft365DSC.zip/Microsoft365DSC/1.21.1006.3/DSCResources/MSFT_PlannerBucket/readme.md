# Description

This resource is used to configure the Planner Buckets.

* This resource deals with content. Using the Monitoring feature
  of Microsoft365DSC on content resources is not recommended.
