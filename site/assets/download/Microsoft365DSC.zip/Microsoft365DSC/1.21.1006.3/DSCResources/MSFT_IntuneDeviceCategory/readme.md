
# IntuneDeviceCategory

This resource configures the Intune device categories.
