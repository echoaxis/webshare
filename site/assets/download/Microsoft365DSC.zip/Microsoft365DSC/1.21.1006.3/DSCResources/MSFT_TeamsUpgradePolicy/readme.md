
# TeamsUpgradePolicy

This resource configures the Teams Upgrade policies.
