# Description

This resource allows to configure Mailtips behaviors in Exchange Online.
