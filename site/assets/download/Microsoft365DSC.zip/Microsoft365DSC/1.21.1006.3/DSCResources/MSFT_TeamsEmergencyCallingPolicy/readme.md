
# TeamsEmergencyCallingPolicy

This resource configures the Teams Emergency Calling Policies.
