# EXOPolicyTipConfig

## Description

This resource configures Policy Tips in Exchange Online.
