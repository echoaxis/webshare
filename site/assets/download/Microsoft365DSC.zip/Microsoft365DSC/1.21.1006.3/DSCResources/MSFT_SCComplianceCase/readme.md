# SCComplianceCase

## Description

This resource configures an eDiscovery Case in Security and Compliance.
