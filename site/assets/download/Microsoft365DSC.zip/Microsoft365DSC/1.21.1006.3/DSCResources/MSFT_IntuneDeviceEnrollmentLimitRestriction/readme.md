
# IntuneDeviceEnrollmentLimitRestriction

This resource configures the Intune device enrollment limit restrictions.
