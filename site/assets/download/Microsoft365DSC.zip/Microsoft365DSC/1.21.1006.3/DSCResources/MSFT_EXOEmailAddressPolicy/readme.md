# EXOEmailAddressPolicy

## Description

This resource configures Email address policies in Exchange Online.
