# SCFilePlanPropertyCitation

## Description

This resource configures a citation entry for Security and
Compliance File Plans.
