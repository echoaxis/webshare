# EXOIntraOrganizationConnector

## Description

Create a new EXOIntraOrganizationConnector in your cloud-based organization.
