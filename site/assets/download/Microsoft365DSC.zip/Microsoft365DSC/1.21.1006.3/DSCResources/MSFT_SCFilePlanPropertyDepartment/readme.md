# SCFilePlanPropertyDepartment

## Description

This resource configures a department entry for Security and
Compliance File Plans.
