# Description

This resource is used to configure the Teams guest calling configuration.
