# AADGroup

## Description

This resource configures an Azure Active Directory group.

## Azure AD Permissions

To authenticate via Azure Active Directory, this resource required the following Application permissions:

* **Automate**
  * None
* **Export**
  * None

NOTE: All permisions listed above require admin consent.
