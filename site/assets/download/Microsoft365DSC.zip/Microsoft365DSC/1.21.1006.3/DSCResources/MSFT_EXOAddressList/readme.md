# EXOAddressList

## Description

This resource configures Exchange Online address lists.
