
# TeamsUpgradeConfiguration

This resource configures the Teams Upgrade settings.
