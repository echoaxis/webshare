# Description

This resource allows users to create Office 365 Users and assign them licenses.
