# EXORemoteDomain

## Description

This resource configures the Remote Email Domains in Exchange Online.
