# EXOActiveSyncDeviceAccessRule

## Description

This resource configures Active Sync Device Access Rules in Exchange Online.
