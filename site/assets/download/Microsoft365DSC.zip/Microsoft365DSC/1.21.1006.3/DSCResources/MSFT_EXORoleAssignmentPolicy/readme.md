# EXORoleAssignmentPolicy

## Description

This resource configures Role Assignment Policies in Exchange Online.
