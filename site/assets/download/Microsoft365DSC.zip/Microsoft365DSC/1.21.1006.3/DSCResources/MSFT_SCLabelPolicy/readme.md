# SCLabelPolicy

## Description

This resource configures a Sensitivity label policy in Security and Compliance.
