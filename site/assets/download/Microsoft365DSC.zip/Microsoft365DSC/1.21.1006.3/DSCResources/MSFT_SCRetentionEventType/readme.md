# SCRetentionEventType

## Description

This resource configures a Retention Event Type in Security and Compliance.
