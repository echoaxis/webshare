# PPTenantSettings

This resource configures a Power Platform Tenant.
