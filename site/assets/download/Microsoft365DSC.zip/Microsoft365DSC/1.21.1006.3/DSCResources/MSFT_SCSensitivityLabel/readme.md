# SCSensitivityLabel

## Description

This resource configures Sensitivity labels in Security and Compliance.
