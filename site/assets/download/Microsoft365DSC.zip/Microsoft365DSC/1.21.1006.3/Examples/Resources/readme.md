For more information about Microsoft365DSC and all of the resources,
including details and examples, please check out our
[Wiki](https://github.com/Microsoft/Microsoft365DSC/wiki)
