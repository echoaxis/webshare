As part of effort to isolate the ReverseDSC Core to allow the community to build additional projects around the module, this repository is now solely focused on managing the ReverseDSC Core. Below is a list of Technology specific scripts that leverage the ReverseDSC Core.

# List of ReverseDSC Orchestrator Scripts
* SharePointDSC.Reverse -> https://github.com/Microsoft/sharepointDSC.reverse
* SQLServerDSC.Reverse -> https://github.com/Microsoft/SQLServerDSC.Reverse
* PSDesiredStateConfiguration.Reverse -> https://github.com/Microsoft/PSDesiredStateConfiguration.Reverse
* RemoteDesktopSessionHostDSC.Reverse -> https://github.com/Microsoft/RemoteDesktopSessionHostDSC.Reverse
* WebAdministrationDSC.Reverse -> https://github.com/Microsoft/WebAdministrationDSC.Reverse
